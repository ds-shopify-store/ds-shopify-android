DS Shopify Android starter project
==================================
Design: black + gold
Package: com.dsstore.app
Minimum Android: API 23

IMPORTANT
- This project uses the existing demo-store concept and is not yet connected to live Shopify products, inventory, checkout, payments, or order tracking.
- The "Visit Official Shopify Store" button opens https://dsshopi-store.myshopify.com.
- Replace sample products in app/src/main/assets/index.html with real Shopify integration before accepting real orders.

BUILD APK
1. Install Android Studio on a computer and open this project folder.
2. Allow Gradle sync and install the Android SDK requested by Android Studio.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Debug APK output: app/build/outputs/apk/debug/app-debug.apk

This ZIP is Android source/project files, not a compiled APK.
